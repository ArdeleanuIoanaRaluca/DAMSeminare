package com.example.oooo;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProfesoriDetailActivity extends AppCompatActivity {

    TextView textViewId, textViewName,textViewAdress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sucursale_detail);

        textViewId = (TextView) findViewById(R.id.textviewId);
        textViewName = (TextView) findViewById(R.id.textviewName);
        textViewAdress = (TextView) findViewById(R.id.textviewAdress);


        Bundle bundle = getIntent().getExtras();
        Profesori sucursale = (Profesori) bundle.getSerializable("Sucursale");

        textViewId.setText("ID - "+sucursale.getId());
        textViewName.setText("NAME - "+sucursale.getName());
        textViewAdress.setText("ADRESS - "+sucursale.getAdress());


    }


}
