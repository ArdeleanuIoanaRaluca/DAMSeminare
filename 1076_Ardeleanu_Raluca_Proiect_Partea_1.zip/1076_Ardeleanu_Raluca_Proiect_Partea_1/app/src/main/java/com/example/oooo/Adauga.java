package com.example.oooo;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class Adauga extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{


    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ActionBarDrawerToggle toogle;

    public static final String ADAUGA_SUCURSALA_KEY = "adauga_sucursala";

    private EditText editTextId;
    private EditText editTextName;
    private EditText editTextAdress;

    private Button btnADD;

    private Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adauga);

        initComponents();

        intent = getIntent();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(R.id.drawerAdauga);
        navigationView = findViewById(R.id.navmenu);
        navigationView.setItemIconTintList(null);
        toogle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(toogle);
        toogle.setDrawerIndicatorEnabled(true);
        navigationView.setNavigationItemSelectedListener((NavigationView.OnNavigationItemSelectedListener) this);
        toogle.syncState();
    }

    private void initComponents() {
        editTextId= findViewById(R.id.editTextNumber9);
        editTextName= findViewById(R.id. editTextTextMultiLine1);
        editTextAdress = findViewById(R.id. editTextTextMultiLine2);
        btnADD = findViewById(R.id.button2);
        btnADD.setOnClickListener(addSaveEventListener());

    }

    private View.OnClickListener addSaveEventListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {
                    Profesori sucursale = adaugaSucursale();
                    intent.putExtra(ADAUGA_SUCURSALA_KEY, sucursale);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        };
    }


    private boolean validate() {

        if (editTextId.getText() == null
                || editTextId.getText().toString().trim().length() < 1) {
            Toast.makeText(getApplicationContext(),
                    R.string.adauga_sucursale_id_error_message,
                    Toast.LENGTH_SHORT)
                    .show();
            return false;
        }

        if (editTextName.getText() == null
                || editTextName.getText().toString().trim().length() < 2) {
            Toast.makeText(getApplicationContext(),
                    R.string.adauga_sucursale_name_error_message,
                    Toast.LENGTH_SHORT)
                    .show();
            return false;
        }

        if (editTextAdress.getText() == null
                || editTextAdress.getText().toString().trim().length() <2) {
            Toast.makeText(getApplicationContext(),
                    R.string.adauga_sucursale_adress_error_message,
                    Toast.LENGTH_SHORT)
                    .show();
            return false;
        }


        return true;
    }

    private Profesori adaugaSucursale() {


        int id = Integer.parseInt(editTextId.getText().toString());
        String name = editTextName.getText().toString();
        String adress = editTextAdress.getText().toString();

        return new Profesori(id, name, adress);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.nav_home:
                Intent home = new Intent(this, MainActivity.class);
                startActivity(home);
                break;
            case R.id.nav_about:
                Intent about = new Intent(this, Adauga.class);
                startActivity(about);
                break;


        }

        drawerLayout = (DrawerLayout) findViewById(R.id.drawerAdauga);
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
}}
