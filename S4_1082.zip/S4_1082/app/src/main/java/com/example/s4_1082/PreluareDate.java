package com.example.s4_1082;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PreluareDate extends AppCompatActivity {
   Persoana persoana;
   Button buton;
   EditText ed_nume,ed_prenume,ed_email,ed_data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preluare_date);
   persoana= new Persoana();
   buton=findViewById(R.id.button2);
   ed_nume=findViewById(R.id.ed_name);
   ed_prenume=findViewById(R.id.ed_firstName);
   ed_email=findViewById(R.id.ed_mail);
   ed_data=findViewById(R.id.ed_data);
   buton.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
           if(isValid()){
           persoana.setNume(ed_nume.getText().toString());
           persoana.setPrenume(ed_prenume.getText().toString());
           persoana.setEmail(ed_email.getText().toString());
           persoana.setDataNastere(ed_data.getText().toString());
           //Toast.makeText(PreluareDate.this,persoana.toString(),Toast.LENGTH_LONG).show() ;
          Bundle bundle= new Bundle();
          bundle.putParcelable("OK",persoana);
          Intent intent=new Intent();
          intent.putExtra("persoanabundle", String.valueOf(bundle));
          setResult(RESULT_OK,intent);
          finish();

           }}
   });


    }

    private Boolean isValid() {
        if (ed_nume.getText().toString().isEmpty()) {
            Toast.makeText(PreluareDate.this, "Campul pentru nume nu este completat", Toast.LENGTH_LONG).show();
            return false;
        }
        if (ed_prenume.getText().toString().isEmpty()) {
            Toast.makeText(PreluareDate.this, "Campul pentru prenume nu este completat", Toast.LENGTH_LONG).show();
            return false;
        }
        if(!isEmailValid(ed_email.getText().toString()))
        {
            Toast.makeText(PreluareDate.this, "Emailul nu respecta formatul", Toast.LENGTH_LONG).show();
            return false;
        }
        if (ed_data.getText().toString().isEmpty()) {
            Toast.makeText(PreluareDate.this, "Campul pentru data nu este completat", Toast.LENGTH_LONG).show();
            return false;
        }
    return true;
    }
    public boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }



}
