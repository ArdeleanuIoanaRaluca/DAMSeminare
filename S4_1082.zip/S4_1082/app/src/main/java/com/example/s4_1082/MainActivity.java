package com.example.s4_1082;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
  private Button btn;
  private TextView txt;
  private final int MAIN_ACTIVITY_REQUEST_CODE=100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt=findViewById(R.id.textView);
        btn=findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this,PreluareDate.class);
                //startActivity(intent);
                startActivityForResult(intent,MAIN_ACTIVITY_REQUEST_CODE);
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==MAIN_ACTIVITY_REQUEST_CODE)
        {
            if(requestCode==RESULT_OK)
            {
                if(data!=null)
                {
                    Bundle bundle=data.getBundleExtra("persoanabundle");
                    Persoana persoana=bundle.getParcelable("ok");
                    txt.setText(persoana.toString());
                }

            }
        }

    }
}