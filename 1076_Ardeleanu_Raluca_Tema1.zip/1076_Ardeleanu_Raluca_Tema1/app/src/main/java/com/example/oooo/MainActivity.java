package com.example.oooo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private static final int ADAUGA_SUCURSALA_REQUEST_CODE = 210;

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ActionBarDrawerToggle toogle;
    ListView listView;
    ArrayList<Sucursale> arrayList;
    ArrayAdapter<Sucursale> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(R.id.drawer);
        navigationView = findViewById(R.id.navmenu);
        navigationView.setItemIconTintList(null);
        toogle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(toogle);
        toogle.setDrawerIndicatorEnabled(true);
        navigationView.setNavigationItemSelectedListener(this);
        toogle.syncState();

        listView = (ListView) findViewById(R.id.list_view);
        arrayList = new ArrayList<>();

        Sucursale s1 = new Sucursale(1, "BC-Buzau", "Str:Unirii, nr: 45");
        Sucursale s2 = new Sucursale(2, "BC-Focsani", "Str:Lalelelor, nr: 20");
        Sucursale s3 = new Sucursale(3, "BC-Bucuresti", "Str:Universitatii, nr: 205A");

        arrayList.add(s1);
        arrayList.add(s2);
        arrayList.add(s3);

        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Sucursale s = arrayList.get(position);

                Bundle bundle = new Bundle();
                bundle.putSerializable("Sucursale", s);

                Intent intent = new Intent(MainActivity.this, SucursaleDetailActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onNavigationItemSelected( MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.nav_home:
                Intent home = new Intent(this, MainActivity.class);
                startActivity(home);
                break;
            case R.id.nav_about:
                Intent intent = new Intent(getApplicationContext(), Adauga.class);
                startActivityForResult(intent,  ADAUGA_SUCURSALA_REQUEST_CODE);
                break;

        }

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }





    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode ==  ADAUGA_SUCURSALA_REQUEST_CODE
                && resultCode == RESULT_OK && data != null) {
            Sucursale s = (Sucursale) data
                    .getSerializableExtra(Adauga.ADAUGA_SUCURSALA_KEY);
            if (s != null) {
                Toast.makeText(getApplicationContext(),
                        R.string.main_message,
                        Toast.LENGTH_SHORT)
                        .show();
                arrayList.add(s);
                notifyAdapter();
            }
        }
    }


    private void adaugaFilmAdapter() {
        arrayAdapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_1, arrayList);

        listView.setAdapter(arrayAdapter);
    }

    private void notifyAdapter() {

        ArrayAdapter adapter = (ArrayAdapter) listView.getAdapter();
        adapter.notifyDataSetChanged();
    }
}