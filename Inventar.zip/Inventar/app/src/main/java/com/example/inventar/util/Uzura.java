package com.example.inventar.util;

public enum Uzura {
    mica, medie, mare
}
