package com.example.inventar.asynkTask;

public interface Callback<R> {

    void runResultOnUiThread(R result);
}
