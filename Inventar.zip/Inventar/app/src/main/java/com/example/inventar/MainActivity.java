package com.example.inventar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.inventar.asynkTask.AsyncTaskRunner;
import com.example.inventar.asynkTask.Callback;
import com.example.inventar.network.HttpManager;
import com.example.inventar.util.DateConverter;
import com.example.inventar.util.Network_xml;
import com.example.inventar.util.ObiectInventar;
import com.example.inventar.util.ObiecteInventarJsonParser;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;

public class MainActivity extends AppCompatActivity {
    private static final int ADD_OBIECT_REQUEST_CODE = 210;

    private static final int LIST_OBIECT_REQUEST_CODE = 220;
    public static final String SHARED_PREF_FILE_NAME = "mainSharedPref";
    public static final String CURRENT_TIME ="date";
    private final DateConverter dateConverter = new DateConverter();
    public static final String OBIECTE_URL = "https://api.jsonbin.io/b/600f4377d4d77374a3f4b81a";
    private SharedPreferences preferences;
    private TextView tv_numeStud;
    String date;
    Bundle bundle;
    List<ObiectInventar> obiecteInventar;
    private AsyncTaskRunner asyncTaskRunner = new AsyncTaskRunner();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        obiecteInventar = new ArrayList<>();
        initComponents();
        getObiecteFromHttp();
        parsareXml();

    }


    private void parsareXml()
    {
        Log.e("Lifecycle", "Eroare XML -POST");
        Network_xml n = new Network_xml(){
            @Override
            protected void onPostExecute(InputStream inputStream) {
                //Toast.makeText(getApplicationContext(), Network_xml.sbuf, Toast.LENGTH_LONG).show();
                obiecteInventar.addAll(obiecte);

                Log.e("Lifecycle", "Eroare XML -POST");
            }
        };
        try {
            n.execute(new URL("https://pastebin.com/raw/PEhMEkuK"));
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Log.e("Lifecycle", "Eroare XML - nu am luat link");
        }

    }
    private void initComponents() {

        //deschidere fisier, daca numele specificat nu exista atunci acesta o sa fie creat pe loc.
        preferences = getSharedPreferences(SHARED_PREF_FILE_NAME, MODE_PRIVATE);
        tv_numeStud = findViewById(R.id.textView);
        getMainDetailsFromSharedPreference();
    }
    private void getObiecteFromHttp() {
        //definim un obiect de tip Callable pe care dorim sa-l procesam pe un alt fir de executie (RunnableTask)
        //HttpManager implementeaza aceasta interfata.
        Callable<String> asyncOperation = new HttpManager(OBIECTE_URL);
        //definim Callback-ul, adica zona din activitatea unde dorim sa receptionam rezultatul procesarii paralele
        //realizata de Callable
        Callback<String> mainThreadOperation = receiveObiecteFromHttp();
        //Apelam asyncTaskRunner cu operation asincrona si zona de cod din activitate unde dorim sa primim raspunsul
        asyncTaskRunner.executeAsync(asyncOperation, mainThreadOperation);
    }
    private Callback<String> receiveObiecteFromHttp() {
        return new Callback<String>() {
            @Override
            public void runResultOnUiThread(String result) {
                Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                obiecteInventar.addAll(ObiecteInventarJsonParser.fromJson(result));
                Log.e("Lifecycle", String.valueOf(obiecteInventar.size()));
            }
        };
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //validarea pe campurile requestCode si resultCode pentru a identifica operatia de adaugare cheltuiala

        if (requestCode == ADD_OBIECT_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            ObiectInventar obInventar = (ObiectInventar) data.getSerializableExtra(AddActivity.OBIECT_KEY);

            Log.e("Lifecycle", obInventar.getDenumire());
            if (obInventar != null) {
                obiecteInventar.add(obInventar);
            }
        }
    }
//
//    @Override
//    protected void onStop() {
//        super.onStop();
//        saveDateDetailsEventListener();
//    }

    private void saveDateDetailsEventListener() {
       saveDateDetailsToSharedPreference();
       finish();

    }
    private void saveDateDetailsToSharedPreference() {

        //definire editor pentru a putea scrie in fisierul de preferinte
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(CURRENT_TIME, dateConverter.toString( Calendar.getInstance().getTime()));
        editor.apply(); // lipsa acestui apel duce la pirderea modificarilor efectuate prin metodele put
    }
    private void getMainDetailsFromSharedPreference() {
        date = preferences.getString(CURRENT_TIME, "");
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        if (item.getItemId() == R.id.menu_about) {
            tv_numeStud.setText(getString(R.string.nume_stud)+date);
        }
        if (item.getItemId() == R.id.menu_add) {
            Intent intent = new Intent(getApplicationContext(), AddActivity.class);
            startActivityForResult(intent, ADD_OBIECT_REQUEST_CODE);
        }
        if (item.getItemId() == R.id.menu_list) {
            bundle=new Bundle();
            bundle.putSerializable("Obiecte", (Serializable) obiecteInventar);

            Intent intent = new Intent(getApplicationContext(), ListActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);
        }
        return true;
    }
}