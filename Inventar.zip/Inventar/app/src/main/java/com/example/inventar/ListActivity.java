package com.example.inventar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.inventar.util.ObiectInventar;
import com.example.inventar.util.ObiectInventarAdapter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static java.util.Comparator.comparing;

public class ListActivity extends AppCompatActivity {

    private ListView lvObiecte;
    private List<ObiectInventar> obiecteInv = new ArrayList<>();
    private Button btnSort;
    boolean isCresc = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        lvObiecte = findViewById(R.id.lv_obiecte);
        Bundle bundle = getIntent().getExtras();
        obiecteInv = (ArrayList<ObiectInventar>) bundle.getSerializable("Obiecte");
        Log.e("Lifecycle", String.valueOf(obiecteInv.size()));
        addObiecteAdapter();

        btnSort = findViewById(R.id.buttonSort);
        btnSort.setOnClickListener(sortItems());
    }

    private void addObiecteAdapter() {
        //adaugare adapter pentru listview
//        ArrayAdapter<BankAccount> adapter = new ArrayAdapter<>(getApplicationContext(),
//                android.R.layout.simple_list_item_1, bankAccounts);
        ObiectInventarAdapter adapter = new ObiectInventarAdapter(getApplicationContext(),
                R.layout.lv_row_view, obiecteInv, getLayoutInflater());
        lvObiecte.setAdapter(adapter);
    }
    private void notifyAdapter() {
        //notificare adapter ca s-a adaugat un nou element in lista
        ArrayAdapter adapter = (ArrayAdapter) lvObiecte.getAdapter();
        adapter.notifyDataSetChanged();
    }


    private View.OnClickListener sortItems(){
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isCresc){
                    Collections.sort(obiecteInv, Collections.reverseOrder());
                    isCresc = false;
                    notifyAdapter();
                }
                else {
                    Collections.sort(obiecteInv, Collections.reverseOrder());
                    isCresc = true;
                    notifyAdapter();
                }
            }
        };
    }
}