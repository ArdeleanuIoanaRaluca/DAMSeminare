package com.example.inventar.util;

import android.os.AsyncTask;
import android.util.Log;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class Network_xml extends AsyncTask<URL, Void, InputStream> {

    InputStream ist = null;

    public ObiectInventar ob;

    public static String sbuf = null;
    DateConverter dateConverter = new DateConverter();
    UzuraConverter uzuraConverter = new UzuraConverter();
    public List<ObiectInventar> obiecte = new ArrayList<>();
    @Override
    protected InputStream doInBackground(URL... urls) {

        HttpURLConnection conn = null;

        try{
            conn = (HttpURLConnection)urls[0].openConnection();
            conn.setRequestMethod("GET");
            ist = conn.getInputStream();

            Log.e("Lifecycle", "Inainte parsare");
            Parsing(ist);
            Log.e("Lifecycle", "Dupa parsare");
            InputStreamReader isr = new InputStreamReader(ist);
            BufferedReader br = new BufferedReader(isr);


        } catch (IOException e) {
            e.printStackTrace();
            Log.e("Lifecycle", "CATCH");
        }

        return ist;
    }

    public static Node getNodeByName(String nodeName, Node parentNode) throws Exception {

        if (parentNode.getNodeName().equals(nodeName)) {
            return parentNode;
        }

        NodeList list = parentNode.getChildNodes();
        for (int i = 0; i < list.getLength(); i++)
        {
            Node node = getNodeByName(nodeName, list.item(i));
            if (node != null) {
                return node;
            }
        }
        return null;
    }

    public static String getAttributeValue(Node node, String attrName) {
        try {
            return ((Element)node).getAttribute(attrName);
        }
        catch (Exception e) {
            return "";
        }
    }

    public void Parsing(InputStream isr)
    { XmlPullParserFactory parserFactory;
        try {
            Log.e("lifecycle","ParsezXML");
            parserFactory= XmlPullParserFactory.newInstance();
            XmlPullParser parser=parserFactory.newPullParser();

            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES,false);
            parser.setInput(isr,null);
            processParsing(parser);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    private void processParsing (XmlPullParser parser) throws IOException, XmlPullParserException
    {
//        ArrayList<ObiectInventar> obiecte=new ArrayList<>();
        Log.e("lifecycle","Procesez parsarea");
        int eventype=parser.getEventType();

        ObiectInventar obiectXML=null;

        while(eventype!=XmlPullParser.END_DOCUMENT){
            String elemName=null;

            switch (eventype){
                case XmlPullParser.START_TAG:
                    elemName=parser.getName();

                    if("obiectinventar".equals(elemName)){
                        obiectXML=new ObiectInventar();
                        obiecte.add(obiectXML);
                    }
                    else if(obiectXML!=null){
                        if("denumire".equals(elemName)){
                            obiectXML.setDenumire(parser.nextText());
                        }
                        else if("numarinventar".equals(elemName)){
                            obiectXML.setNumarInventar
                                    (Integer.parseInt( parser.nextText()));
                        }
                        else if("dataadaugarii".equals(elemName)){
                            obiectXML.setDataAdaugarii
                                    (dateConverter.fromString( parser.nextText()));
                        }
                        else if("valoare".equals(elemName)){
                            obiectXML.setValoare(Float.parseFloat( parser.nextText()));
                        }
                        else if("uzura".equals(elemName)){
                            obiectXML.setUzura
                                    (uzuraConverter.fromString( parser.nextText()));
                        }
                    }
                    break;
            }
            eventype=parser.next();
        }

    }
}