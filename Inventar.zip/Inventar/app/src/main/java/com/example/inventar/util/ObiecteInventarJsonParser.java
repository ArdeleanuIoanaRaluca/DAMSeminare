package com.example.inventar.util;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ObiecteInventarJsonParser {
    public static final String DENUMIRE = "denumire";
    public static final String NUMAR_INVENTAR = "numarInventar";
    public static final String DATA_ADAUGARII="dataAdaugarii";
    public static final String VALOARE = " valoare";
    public static final String UZURA = "uzura";
    private static final DateConverter dateConverter = new DateConverter();

    private static final UzuraConverter uzuraConverter = new UzuraConverter();

    public static List<ObiectInventar> fromJson(String json) {
        try {
            Log.e("Lifecycle", "lallaaa FROM JSON");
            JSONArray array = new JSONArray(json);
            return readObiecte(array);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    private static List<ObiectInventar> readObiecte(JSONArray array) throws JSONException {
        List<ObiectInventar> obiecte = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            ObiectInventar obiect = readObiect(array.getJSONObject(i));
            obiecte.add(obiect);
            Log.e("Lifecycle sunt in for", obiect.getDenumire());
        }
        return obiecte;
    }
    private static ObiectInventar readObiect(JSONObject object) throws JSONException {
        String denumire = object.getString(DENUMIRE);
        int numarInventar = Integer.parseInt(object.getString(NUMAR_INVENTAR));
        Date dataAdaugarii = dateConverter.fromString(object.getString(DATA_ADAUGARII));
        float valoare = Float.parseFloat(object.getString(VALOARE));
        Uzura uzura = uzuraConverter.fromString(object.getString(UZURA));
        Log.e("Lifecycle", denumire);
        return new ObiectInventar(denumire, numarInventar, dataAdaugarii, valoare, uzura);
    }
}
