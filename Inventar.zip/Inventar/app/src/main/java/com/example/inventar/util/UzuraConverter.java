package com.example.inventar.util;

public class UzuraConverter {

    public static String fromUzura(Uzura uzura) {
        if (uzura == null) {
            return null;
        }
        return uzura.name(); //"CSIE";
    }

    public static Uzura fromString(String facultateString) {
        if (facultateString == null || facultateString.isEmpty()) {
            return null;
        }
        return Uzura.valueOf(facultateString); // facultate.name().equals(facultateString);
    }

}
