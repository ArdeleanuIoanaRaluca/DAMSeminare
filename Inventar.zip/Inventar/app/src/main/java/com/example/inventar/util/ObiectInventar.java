package com.example.inventar.util;

import java.io.Serializable;
import java.util.Date;

public class ObiectInventar implements Serializable, Comparable<ObiectInventar> {
    private String denumire;
    private int numarInventar;
    private Date dataAdaugarii;
    private float valoare;
    private Uzura uzura;

    public ObiectInventar(String denumire, int numarInventar, Date dataAdaugarii, float valoare, Uzura uzura) {
        this.denumire = denumire;
        this.numarInventar = numarInventar;
        this.dataAdaugarii = dataAdaugarii;
        this.valoare = valoare;
        this.uzura = uzura;
    }

    public ObiectInventar() {

    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public int getNumarInventar() {
        return numarInventar;
    }

    public void setNumarInventar(int numarInventar) {
        this.numarInventar = numarInventar;
    }

    public Date getDataAdaugarii() {
        return dataAdaugarii;
    }

    public void setDataAdaugarii(Date dataAdaugarii) {
        this.dataAdaugarii = dataAdaugarii;
    }

    public float getValoare() {
        return valoare;
    }

    public void setValoare(float valoare) {
        this.valoare = valoare;
    }

    public Uzura getUzura() {
        return uzura;
    }

    public void setUzura(Uzura uzura) {
        this.uzura = uzura;
    }

    @Override
    public String toString() {
        return "ObiectInventar{" +
                "denumire='" + denumire + '\'' +
                ", numarInventar=" + numarInventar +
                ", dataAdaugarii=" + dataAdaugarii +
                ", valoare=" + valoare +
                ", uzura=" + uzura +
                '}';
    }

    @Override
    public int compareTo(ObiectInventar o) {
        if(this.getDenumire().compareTo(o.getDenumire())==1)
            return 1;
        else
            return -1;

    }
}
