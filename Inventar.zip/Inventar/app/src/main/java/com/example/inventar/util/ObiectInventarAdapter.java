package com.example.inventar.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.inventar.R;

import java.util.Date;
import java.util.List;

public class ObiectInventarAdapter extends ArrayAdapter<ObiectInventar> {

    private Context context;
    private List<ObiectInventar> obiecteInv;
    private LayoutInflater inflater;
    private int resource;

    public ObiectInventarAdapter(@NonNull Context context, int resource,
                              @NonNull List<ObiectInventar> objects, LayoutInflater inflater) {
        super(context, resource, objects);
        this.context = context;
        this.obiecteInv = objects;
        this.inflater = inflater;
        this.resource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = inflater.inflate(resource, parent, false);
        ObiectInventar obInv = obiecteInv.get(position);
        if (obInv != null) {
            addDenumire(view, obInv.getDenumire());
            addNumarInventar(view, obInv.getNumarInventar());
            addValoare(view, obInv.getValoare());
            addData(view, obInv.getDataAdaugarii());
            addUzura(view, obInv.getUzura());
        }
        return view;
    }

    private void addDenumire(View view, String denumire) {
        TextView textView = view.findViewById(R.id.tv_denumire);
        populateTextViewContent(textView, denumire);
    }

    private void addNumarInventar(View view, int numarInventar) {
        TextView textView = view.findViewById(R.id.tv_numarInventar);
        populateTextViewContent(textView, String.valueOf(numarInventar));
    }

    private void addValoare(View view, float valoare) {
        TextView textView = view.findViewById(R.id.tv_valoare);
        String cardNumberStr = String.valueOf(valoare);
        populateTextViewContent(textView, String.valueOf(valoare));
    }

    private void addData(View view, Date date) {
        TextView textView = view.findViewById(R.id.tv_data);
        populateTextViewContent(textView, String.valueOf(date));
    }
    private void addUzura(View view, Uzura uzura) {
        TextView textView = view.findViewById(R.id.tv_uzura);
        populateTextViewContent(textView, String.valueOf(uzura));
    }
    private void populateTextViewContent(TextView textView, String value) {
        if (value != null && !value.trim().isEmpty()) {
            textView.setText(value);
        } else {
            textView.setText(R.string.lv_row_view_no_content);
        }
    }
}