package com.example.inventar;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.inventar.util.DateConverter;
import com.example.inventar.util.ObiectInventar;
import com.example.inventar.util.Uzura;
import com.google.android.material.textfield.TextInputEditText;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.widget.ArrayAdapter.createFromResource;

public class AddActivity extends AppCompatActivity {
    public static final String OBIECT_KEY = "obiect_key";
    private final DateConverter dateConverter = new DateConverter();
    private Intent intent;
    private TextInputEditText tietDenumire;
    private TextInputEditText tietNumarInventar;
    private DatePicker dp_date;
    private TextInputEditText tietValoare;
    private Spinner spnUzura;
    private Button btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        initComponents();
        intent = getIntent();
        btnAdd.setOnClickListener(addClickEvent());
    }
    private void initComponents(){
        tietDenumire = findViewById(R.id.tiet_denumire);
        tietNumarInventar = findViewById(R.id.tiet_numarInventar);
        dp_date = findViewById(R.id.dp_date);
        tietValoare = findViewById(R.id.tiet_valoare);
        spnUzura = findViewById(R.id.spinnerUzura);
        btnAdd = findViewById(R.id.buttonAdd);
        populateSpinner();
    }
    private void populateSpinner(){
        ArrayAdapter<CharSequence> adapter = createFromResource(getApplicationContext(),
                R.array.uzura,
                android.R.layout.simple_spinner_dropdown_item);
        Log.e("Lifecycle", "lalalalal");
        //atasam adapter catre spinner
        spnUzura.setAdapter(adapter);
    }
    private View.OnClickListener addClickEvent(){
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()){
                    ObiectInventar obiectInventar = buildObiectInventar();
                    intent.putExtra(OBIECT_KEY, obiectInventar);
                    Log.e("Lifecycle", obiectInventar.getDenumire());
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        };
    }

    private boolean validate(){
        if (tietDenumire.getText() == null || tietDenumire.getText().toString().trim().length() < 3) {
            Toast.makeText(getApplicationContext(),
                    R.string.error_denumire,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }
        if (tietNumarInventar.getText() == null || tietNumarInventar.getText().toString().trim().length() == 0 ||
                Integer.parseInt(tietNumarInventar.getText().toString()) <0) {
            Toast.makeText(getApplicationContext(),
                    R.string.error_numarInventar,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }
        if (tietValoare.getText() == null || tietValoare.getText().toString().trim().length() < 3) {
            Toast.makeText(getApplicationContext(),
                    R.string.error_valoare,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }
        return true;
    }

    private ObiectInventar buildObiectInventar() {
        String denumire = tietDenumire.getText().toString();
        int numarInventar = Integer.parseInt(tietNumarInventar.getText().toString());
        Date dataAdaugarii;
        Date date1= (Date) new Date
                (dp_date.getYear(), dp_date.getMonth(), dp_date.getDayOfMonth());
        float valoare = Float.parseFloat(tietValoare.getText().toString());
        Uzura uzura = Uzura.mica;
        if(spnUzura.getSelectedItem().toString()=="mica")
            uzura=Uzura.mica;
        if(spnUzura.getSelectedItem().toString()=="medie")
            uzura=Uzura.medie;
        if(spnUzura.getSelectedItem().toString()=="mare")
            uzura=Uzura.mare;

        return new ObiectInventar(denumire, numarInventar, date1, valoare, uzura);
    }

}