package com.example.seminar_1076listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class EmployeeDetailActivity extends AppCompatActivity {

    TextView textViewId, textViewName,textViewSurname, textViewSalary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_detail);

        textViewId = (TextView) findViewById(R.id.textviewId);
        textViewName = (TextView) findViewById(R.id.textviewName);
        textViewSurname = (TextView) findViewById(R.id.textviewSurname);
        textViewSalary = (TextView) findViewById(R.id.textviewSalary);

        Bundle bundle = getIntent().getExtras();
        Employee employee = (Employee) bundle.getSerializable("EMPLOYEE");

        textViewId.setText("ID - "+employee.getId());
        textViewName.setText("NAME - "+employee.getName());
        textViewSurname.setText("SURNAME - "+employee.getSurname());
        textViewSalary.setText("SALARY - "+employee.getSalary());

    }
}