package com.example.seminar_1076listview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Employee> arrayList;
    ArrayAdapter<Employee> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.list_view);
        arrayList = new ArrayList<>();

        Employee e1 = new Employee(1, "Ionescu", "Marcel", 1000);
        Employee e2 = new Employee(2, "Popescu", "Vasile", 2000);
        Employee e3 = new Employee(3, "Ionescu", "Aurel", 3000);

        arrayList.add(e1);
        arrayList.add(e2);
        arrayList.add(e3);

        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Employee e = arrayList.get(position);

                Bundle bundle = new Bundle();
                bundle.putSerializable("EMPLOYEE", e);

                Intent intent = new Intent(MainActivity.this, EmployeeDetailActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);

            }
        });

    }
}
