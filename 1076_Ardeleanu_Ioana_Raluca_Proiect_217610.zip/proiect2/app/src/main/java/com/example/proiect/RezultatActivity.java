package com.example.proiect;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
public class RezultatActivity extends AppCompatActivity {

    TextView mGrade, mFinalScore;
        Button mRetryButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rezultat);

            mGrade = (TextView)findViewById(R.id.grade);
            mFinalScore = (TextView)findViewById(R.id.outOf);
            mRetryButton = (Button)findViewById(R.id.retry);
            Bundle bundle = getIntent().getExtras();
            int score = bundle.getInt("rezultatFinal");

            mFinalScore.setText("Rezultatul tau este de " + score + " din  " + Intrebari.mQuestions.length);

            if (score == 4){
                mGrade.setText("Promovat");
            }else {
                mGrade.setText("Picat");
            }

            mRetryButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(RezultatActivity.this, IntrebariActivity.class));
                    RezultatActivity.this.finish();
                }
            });

        }
    }
