package com.example.proiect;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ParereDao {

    @Query("SELECT * FROM pareri ORDER BY ID ")
    List<Pareri> loadAllPareri();

    @Insert
    void insertParere(Pareri p);

//    @Update
//    void updatePerson(Person person);

    @Delete
    void delete(Pareri pareri);

    @Query("SELECT * FROM pareri WHERE id = :id")
    Pareri loadPareriById(int id);
}