package com.example.proiect;

public class Profesori {

    String nume;
    String prenume;
    String scoala;
    String varsta;
   String email;


    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public String getScoala() {
       return scoala;
    }

    public void setScoala(String scoala) {
        this.scoala = scoala;
    }

    public String getVarsta() {
       return varsta;
    }

    public void setVarsta(String varsta) {
        this.varsta = varsta;
    }

    public String getEmail() {
       return email;
   }

    public void setEmail(String email) {
        this.email = email;
   }
}
