package com.example.proiect;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter {
    Context context;
    ArrayList<Profesori> arrayList;

    public CustomAdapter(Context context, ArrayList<Profesori> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView==null){
            convertView= LayoutInflater.from(context).inflate(R.layout.item_list,parent,false);
        }
        TextView nume, prenume, scoala, varsta, email;
        nume=(TextView) convertView.findViewById(R.id.nume);
        prenume=(TextView) convertView.findViewById(R.id.prenume);
        scoala=(TextView) convertView.findViewById(R.id.scoala);
        varsta=(TextView) convertView.findViewById(R.id.varsta);
        email=(TextView) convertView.findViewById(R.id.email);

        nume.setText(arrayList.get(position).getNume());
        prenume.setText(arrayList.get(position).getPrenume());
       scoala.setText(arrayList.get(position).getScoala());
       varsta.setText(arrayList.get(position).getVarsta());
        email.setText(arrayList.get(position).getEmail());

        return convertView;
    }
}
