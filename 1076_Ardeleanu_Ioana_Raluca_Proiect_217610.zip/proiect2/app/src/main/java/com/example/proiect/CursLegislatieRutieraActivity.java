package com.example.proiect;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;

public class CursLegislatieRutieraActivity extends AppCompatActivity {

    PDFView v;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_curs_legislatie_rutiera);
    v=(PDFView) findViewById(R.id.cursLegi);
    v.fromAsset("curs_legislatie.pdf")
        .defaultPage(0)
         .enableAnnotationRendering(true)
            .scrollHandle(new DefaultScrollHandle(this))
            .spacing(2)
            .load();


    }
}