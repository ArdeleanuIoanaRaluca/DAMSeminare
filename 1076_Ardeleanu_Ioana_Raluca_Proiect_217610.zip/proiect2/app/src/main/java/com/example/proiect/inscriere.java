package com.example.proiect;

public class inscriere {

    String nume;
    int varsta;
    String adresa;
    String nrTelefon;

    public inscriere(String nume, int varsta, String adresa, String nrTelefon) {
        this.nume = nume;
        this.varsta = varsta;
        this.adresa = adresa;
        this.nrTelefon = nrTelefon;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public int getVarsta() {
        return varsta;
    }

    public void setVarsta(int varsta) {
        this.varsta = varsta;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public String getNrTelefon() {
        return nrTelefon;
    }

    public void setNrTelefon(String nrTelefon) {
        this.nrTelefon = nrTelefon;
    }
}
