package com.example.proiect;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "pareri")
public class Pareri {
    @PrimaryKey(autoGenerate = true)
    int id;
    String nume;
    String parere;


    @Ignore
    public Pareri(String nume, String parere) {
        this.nume = nume;
        this.parere = parere;


    }

    public Pareri(int id, String nume, String parere) {
        this.id = id;
        this.nume = nume;
        this.parere = parere;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getParere() {
        return parere;
    }

    public void setParere(String parere) {
        this.parere = parere;
    }

}
