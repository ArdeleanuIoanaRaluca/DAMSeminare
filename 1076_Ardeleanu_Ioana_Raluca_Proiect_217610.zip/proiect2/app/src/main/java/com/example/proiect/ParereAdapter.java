package com.example.proiect;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ParereAdapter extends RecyclerView.Adapter<ParereAdapter.MyViewHolder> {
    private Context context;
    private List<Pareri> mParereList;

    public ParereAdapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.pareri_item, viewGroup, false);
        return new MyViewHolder(view);
    }



    @Override
    public void onBindViewHolder(@NonNull ParereAdapter.MyViewHolder myViewHolder, int i) {
        myViewHolder.nume.setText(mParereList.get(i).getNume());
        myViewHolder.parere.setText(mParereList.get(i).getParere());

    }

    @Override
    public int getItemCount() {
        if (mParereList == null) {
            return 0;
        }
        return mParereList.size();

    }

    public void setTasks(List<Pareri> parereList) {
        mParereList = parereList;
        notifyDataSetChanged();
    }

    public List<Pareri> getTasks() {

        return mParereList;
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView nume, parere;
        AppDatabase mDb;

        MyViewHolder(@NonNull final View itemView) {
            super(itemView);
            mDb = AppDatabase.getInstance(context);
            nume = itemView.findViewById(R.id.person_name);
            parere = itemView.findViewById(R.id.person_parere);



        }
    }
}
