package com.example.proiect;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ListaScoliAutoDetailActivity extends AppCompatActivity  {

    TextView textViewId, textViewName,textViewAdress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listascoliauto_detail);

        textViewId = (TextView) findViewById(R.id.textviewId);
        textViewName = (TextView) findViewById(R.id.textviewName);
        textViewAdress = (TextView) findViewById(R.id.textviewAdress);


        Bundle bundle = getIntent().getExtras();
        ListaScoliAuto scoli = (ListaScoliAuto) bundle.getSerializable("Lista Scoli Auto");

        textViewId.setText("ID  "+scoli.getId());
        textViewName.setText("NUME  "+scoli.getName());
        textViewAdress.setText("ADRESA  "+scoli.getAdress());


    }


}
