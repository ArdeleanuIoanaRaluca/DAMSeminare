package com.example.proiect;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class DomeniuDeInvatareActivity extends AppCompatActivity {
    Button buttonLegislatie,buttonintrebari;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_domeniu_de_invatare);


        buttonintrebari = (Button) findViewById(R.id.buttonintrebari);
        buttonintrebari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openIntrebariActivity();
            }
        });


        buttonLegislatie=(Button)findViewById(R.id.buttonLegislatie);
        buttonLegislatie.setOnClickListener(new View.OnClickListener()
        {@Override
            public void onClick(View v) {
                openLegislatieActivity(); }});
    }
    private void openLegislatieActivity() {
        Intent l= new Intent(this,LegislatieActivity.class);
        startActivity(l);}
        private void openIntrebariActivity() {
            Intent intrebari= new Intent(this,IntrebariActivity.class);
            startActivity(intrebari);
    }





    }


