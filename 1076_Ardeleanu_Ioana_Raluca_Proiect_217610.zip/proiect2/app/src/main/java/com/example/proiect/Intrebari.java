package com.example.proiect;

public class Intrebari {
    public static String mQuestions [] = {
            "Se interzice circulatia pe drumurile publice a autovehiculelor daca:",
            " Cum veti semnaliza faptul ca autovehiculul cu care circulati a ramas in pana pe partea carosabila?",
            "Acvaplanarea poate fi evitata atunci cand:",
            "Ce categorii de persoane sunt exceptate de la obligatia de a purta centura de siguranta?"

    };


    private String mChoices [][] = {
            {" echipamentul de franare este defect;", "emisia de gaze atinge limita legala admisa;", "nu au montate dispozitive de iluminare si de semnalizare, altele decat cele omologate de autoritatea competenta"},
            {"prin folosirea luminilor de pozitie", "prin purtarea vestei reflectorizante", "Nu semnalizez"},
            {"pneurile sunt bune si viteza este redusa", "autovehicului este dotat cu ABS", "autovehiculul este supraincarca"},
            {"conducatorii autoturismelor, atunci cand executa manevra de mers inapoi sau cand stationeaza;", "tinerii care nu au împlinit 14 ani", "persoanele varstice"}
    };



    public static String mCorrectAnswers[] = {" echipamentul de franare este defect;", "prin folosirea luminilor de pozitie", "pneurile sunt bune si viteza este redusa", "conducatorii autoturismelor, atunci cand executa manevra de mers inapoi sau cand stationeaza;"};




    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }


    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }


    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswers[a];
        return answer;
    }
}
