package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MeniuAdapter extends BaseAdapter {
    private List<Meniuri> listaMeniuri=new ArrayList<>();

    public MeniuAdapter(List<Meniuri> lista) {

       listaMeniuri=lista;
    }

    @Override
    public int getCount() {
        return listaMeniuri.size();
    }

    @Override
    public Meniuri getItem(int i) {
        return listaMeniuri.get(i);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflater=LayoutInflater.from(viewGroup.getContext());
        View view1= inflater.inflate(R.layout.item_menu,viewGroup, false);
        TextView textNume= view1.findViewById(R.id.nume);
        TextView textPret= view1.findViewById(R.id.pret);
        TextView textIngrediente= view1.findViewById(R.id.ingrediente);

        Meniuri temp= listaMeniuri.get(position);
        textNume.setText(temp.getNume());
        textPret.setText(temp.getPret()+"");
        textIngrediente.setText(temp.getIngrediente());

        return view1;

    }

    public void updateList(List<Meniuri> lista)
    {
        listaMeniuri.clear();
        listaMeniuri.addAll(lista);

        notifyDataSetChanged();
    }
}
