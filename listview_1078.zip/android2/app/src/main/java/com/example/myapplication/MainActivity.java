package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView=findViewById(R.id.listView);

        MeniuAdapter meniuAdapter = new MeniuAdapter(getList());

        listView.setAdapter(meniuAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Random r = new Random(1);
                int alegere=r.nextInt();

                if(alegere%2==0)
                {
                    meniuAdapter.updateList(getList());
                } else
                    meniuAdapter.updateList(getList2());


            }
        });
    }




    private List<Meniuri> getList()
    {
        ArrayList<Meniuri> lista= new ArrayList<>();

        Meniuri meniu1= new Meniuri("Meniu1",20,"Pulpe de pui");
        Meniuri meniu2= new Meniuri("Meniu2",30,"Pizza");
        Meniuri meniu3= new Meniuri("Meniu3",40,"Paste");

        lista.add(meniu1);
        lista.add(meniu2);
        lista.add(meniu3);
        return lista;


    }

    private List<Meniuri> getList2()
    {
        ArrayList<Meniuri> lista= new ArrayList<>();

        Meniuri meniu4= new Meniuri("Meniu4",20,"Papanasi");
        Meniuri meniu5= new Meniuri("Meniu5",30,"Clatite");
        Meniuri meniu6= new Meniuri("Meniu6",40,"Placita");

        lista.add(meniu4);
        lista.add(meniu5);
        lista.add(meniu6);
        return lista;





    }


}