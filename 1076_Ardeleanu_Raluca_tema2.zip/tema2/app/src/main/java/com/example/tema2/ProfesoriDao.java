package com.example.tema2;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ProfesoriDao {

    @Query("SELECT * FROM profesori ORDER BY ID")
    List<Profesori> loadAllProfesori();

    @Insert
    void insertPerson(Profesori p);

//    @Update
//    void updatePerson(Person person);

    @Delete
    void delete(Profesori p);

    @Query("SELECT * FROM profesori WHERE id = :id")
    Profesori loadProfesoriById(int id);
}