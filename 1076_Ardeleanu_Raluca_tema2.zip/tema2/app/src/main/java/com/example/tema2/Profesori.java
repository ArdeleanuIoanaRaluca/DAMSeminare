package com.example.tema2;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "profesori")
public class Profesori {
    @PrimaryKey(autoGenerate = true)
    int id;
    String name;
    String email;
    String number;
    String materie;

    @Ignore
    public Profesori(String name, String email, String number, String materie) {
        this.name = name;
        this.email = email;
        this.number = number;
        this.materie = materie;

    }

    public Profesori(int id, String name, String email, String number, String materie) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.number = number;
        this.materie = materie;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getMaterie() {
        return materie;
    }

    public void setMaterie(String materie) {
        this.materie = materie;
    }
}
