package com.example.tema2.firebase;

public interface Callback<R> {
    void runResultOnUiThread(R result);
}
