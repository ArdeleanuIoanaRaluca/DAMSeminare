package com.example.tema2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.BreakIterator;
import java.util.List;

public class ProfesoriAdapter extends RecyclerView.Adapter<ProfesoriAdapter.MyViewHolder> {
    private Context context;
    private List<Profesori> mProfesoriList;

    public ProfesoriAdapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.profesori_item, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProfesoriAdapter.MyViewHolder myViewHolder, int i) {
        myViewHolder.name.setText(mProfesoriList.get(i).getName());
        myViewHolder.email.setText(mProfesoriList.get(i).getEmail());
        myViewHolder.number.setText(mProfesoriList.get(i).getNumber());
        myViewHolder.materie.setText(mProfesoriList.get(i).getMaterie());

    }

    @Override
    public int getItemCount() {
        if (mProfesoriList == null) {
            return 0;
        }
        return mProfesoriList.size();

    }

    public void setTasks(List<Profesori> personList) {
        mProfesoriList = personList;
        notifyDataSetChanged();
    }

    public List<Profesori> getTasks() {

        return mProfesoriList;
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView name, email, number,materie;
        AppDatabase mDb;

        MyViewHolder(@NonNull final View itemView) {
            super(itemView);
            mDb = AppDatabase.getInstance(context);
            name = itemView.findViewById(R.id.profesor_name);
            email = itemView.findViewById(R.id.profesor_email);
            number = itemView.findViewById(R.id.profesor_number);
            materie = itemView.findViewById(R.id.profesor_materie);

        }
    }
}
