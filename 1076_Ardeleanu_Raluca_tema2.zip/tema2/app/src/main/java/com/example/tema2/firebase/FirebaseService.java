package com.example.tema2.firebase;

import android.util.Log;

import androidx.annotation.NonNull;


import com.example.tema2.util.Personal;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FirebaseService {
    public static final String COACH_TABLE_NAME = "coaches";
    private DatabaseReference database;

    private static FirebaseService firebaseService;

    private FirebaseService() {
        //acces firebase prin FirebaseDatabase.getInstance
        //initializare conexiune nod referit prin getReference(COACH_TABLE_NAME)
        database = FirebaseDatabase.getInstance().getReference(COACH_TABLE_NAME);
    }

    public static FirebaseService getInstance() {
        if (firebaseService == null) {
            synchronized (FirebaseService.class) {
                if (firebaseService == null) {
                    firebaseService = new FirebaseService();
                }
            }
        }
        return firebaseService;
    }

    public void upsert(Personal personal) {
        if (personal == null) {
            return;
        }
        //verificam daca obiectul coach nu are id
        if (personal.getId() == null || personal.getId().trim().isEmpty()) {
            //adaugam o cheie noua in firebase, mare atentie aceasta nu contine si valorile obiectului coach
            String id = database.push().getKey();
            personal.setId(id);
        }
        //ne pozitionam pe un copil din coaches (cel pe care l-am adaugat la linia 48 daca coach.getId == null,
        //altfel pe cel pe care l-am primit in obiectul coach)
        //setValue asigura adaugarea/suprascrierea informatiilor stocate in copilul pozitionat
        database.child(personal.getId()).setValue(personal);
    }

    public void delete(final Personal personal) {
        if (personal == null || personal.getId() == null || personal.getId().trim().isEmpty()) {
            return;
        }
        //ne pozitionam pe un copil din coaches (cel pe care l-am primit in obiectul coach)
        //removeValue asigura stergerea informatiilor stocate in copilul pozitionat
        database.child(personal.getId()).removeValue();
    }

    public void attachDataChangeEventListener(final Callback<List<Personal>> callback) {
        //evenimentul este atasat la nivel de coaches (reference) prin urmare asculta orice modificare
        // de insert/update/delete executata asupra acestui nod
        //apelul metodelor upsert si delete de mai sus forteaza primirea unei notificari de la Firebase in acest eveniment
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Personal> personals = new ArrayList<>();
                //parcurgem lista de subnoduri din cel principal
                for (DataSnapshot data : snapshot.getChildren()) {
                    //folosim reflection pentru convertirea de la Snapshot la Coach
                    //mare atentie sa definim in Coach un constructor default + getteri si setteri
                    Personal personal = data.getValue(Personal.class);
                    if (personal != null) {
                        personals.add(personal);
                    }
                }
                //trimitem lista catre activitatea prin intermediul callback-ului
                callback.runResultOnUiThread(personals);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.i("FirebaseService", "Data is not available");
            }
        });
    }
}
