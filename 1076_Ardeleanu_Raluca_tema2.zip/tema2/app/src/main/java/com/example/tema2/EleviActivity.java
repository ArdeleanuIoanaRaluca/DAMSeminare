package com.example.tema2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;







public class EleviActivity extends AppCompatActivity  {

    ListView listView;
    ArrayList<Elevi> arrayList;
    SwipeRefreshLayout swipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elevi);

        listView=findViewById(R.id.listView);
        swipeRefreshLayout=findViewById(R.id.swipeRefresh);
        arrayList=new ArrayList<>();

        new JSONTasks().execute();
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new JSONTasks().execute();
            }
        });


    }

    public class JSONTasks extends AsyncTask<String,String,String> {

        @Override
        public void onPreExecute(){
            super.onPreExecute();
            swipeRefreshLayout.setRefreshing(true);
        }

        @Override
        protected String doInBackground(String... strings) {
            arrayList.clear();
            String result=null;
            try {
                URL url = new URL("https://jsonkeeper.com/b/74NZ");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.connect();

                if(conn.getResponseCode()==HttpURLConnection.HTTP_OK){
                    InputStreamReader inputStreamReader = new InputStreamReader(conn.getInputStream());
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    StringBuilder stringBuilder = new StringBuilder();
                    String temp;
                    while((temp= bufferedReader.readLine())!=null){
                        stringBuilder.append(temp);
                    }
                    result=stringBuilder.toString();
                } else {
                    result="error";
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        public void onPostExecute(String s){
            super.equals(s);
            swipeRefreshLayout.setRefreshing(false);

            try {
                JSONObject object = new JSONObject(s);
                JSONArray array = object.getJSONArray("elevi");

                for(int i=0;i<array.length();i++){
                    JSONObject jsonObject = array.getJSONObject(i);
                    String id=jsonObject.getString("id");
                    String name=jsonObject.getString("nume");
                    String anStudiu=jsonObject.getString("anStudiu");


                    Elevi elevi = new Elevi();
                    elevi.setId(id);
                    elevi.setName(name);
                    elevi.setAnStudiu(anStudiu);
                    arrayList.add(elevi);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            CustomAdapter adapter = new CustomAdapter(EleviActivity.this,arrayList);
            listView.setAdapter(adapter);
        }
    }
}