package com.example.tema2;

public class Elevi {

    String id;
    String name;
    String anStudiu;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAnStudiu() {
        return anStudiu;
    }

    public void setAnStudiu(String anStudiu) {
        this.anStudiu = anStudiu;
    }
}
