package com.example.seminar2android;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
   private Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=findViewById(R.id.button2);

        Log.v("lifecycle", "onCreate");

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.v("lifecycle", "onStart");

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v("lifecycle", "onResume");

    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v("lifecycle", "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.v("lifecycle", "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v("lifecycle", "onDestroy");
    }
}