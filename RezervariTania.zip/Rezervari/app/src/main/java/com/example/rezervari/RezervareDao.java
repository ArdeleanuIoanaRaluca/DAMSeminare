package com.example.rezervari;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface RezervareDao {

    @Query("SELECT * FROM rezervare ORDER BY ID")
    List<Rezervare> loadAllRezervare();

    @Insert
    void insertRezervare(Rezervare r);



    @Delete
    void delete(Rezervare r);

    @Query("SELECT * FROM rezervare WHERE id = :id")
    Rezervare loadRezervareById(int id);
}