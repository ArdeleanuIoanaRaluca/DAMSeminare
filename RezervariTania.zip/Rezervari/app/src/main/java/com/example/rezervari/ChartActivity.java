package com.example.rezervari;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChartActivity extends AppCompatActivity {
    public static final String REZERVARE = "rezervare_key";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_chart);

        List<Rezervare> coaches = (List<Rezervare>) getIntent().getSerializableExtra(REZERVARE);

        setContentView(new ChartView(getApplicationContext(), getSource(coaches)));
    }

    private Map<String, Integer> getSource(List<Rezervare> r) {
        if (r == null || r.isEmpty()) {
            return null;
        }
        Map<String, Integer> source = new HashMap<>();
        for (Rezervare rezervare : r) {
            if (source.containsKey(rezervare.getDestinatie())) {
                Integer currentValue = source.get(rezervare.getDestinatie());
                Integer newValue = (currentValue != null ? currentValue : 0) + 1;
                source.put(rezervare.getDestinatie(), newValue);
            } else {
                source.put(rezervare.getDestinatie(), 1);
            }
        }
        return source;
    }
}