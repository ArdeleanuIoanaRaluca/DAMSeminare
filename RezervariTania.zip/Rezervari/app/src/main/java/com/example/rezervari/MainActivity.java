package com.example.rezervari;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int ADD_REZERVARE_REQUEST_CODE = 210;
    Button btn1, btn2, btn3, btn4, btn5;

    List<Rezervare> arrayList = new ArrayList<>();
    


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1= findViewById(R.id.button);
        btn2= findViewById(R.id.button2);
        btn3= findViewById(R.id.button3);
        btn4= findViewById(R.id.button4);
        btn5= findViewById(R.id.button5);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(MainActivity.this, EliberareRezervare.class), ADD_REZERVARE_REQUEST_CODE);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Bundle bundle =new Bundle();
               bundle.putSerializable("Rezervari", (Serializable) arrayList);

               Intent intent = new Intent(getApplicationContext(), ListaRezervari.class);
               intent.putExtras(bundle);
               startActivity(intent);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new JSONTasks().execute();
            }
        });


        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ChartActivity.class);
                intent.putExtra(ChartActivity.REZERVARE, (Serializable) arrayList);
                startActivity(intent);            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_REZERVARE_REQUEST_CODE
                && resultCode == RESULT_OK && data != null) {
            Rezervare r = (Rezervare) data
                    .getSerializableExtra(EliberareRezervare.REZERVARE_KEY);
            if (r != null) {
                Toast.makeText(getApplicationContext(),
                        R.string.main_rezervare_nou_adaugat_message,
                        Toast.LENGTH_SHORT)
                        .show();
                arrayList.add(r);

            }
        }
    }

    public class JSONTasks extends AsyncTask<String,String,String> {

        @Override
        public void onPreExecute(){
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            arrayList.clear();
            String result=null;
            try {
                URL url = new URL("https://jsonkeeper.com/b/L80W");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.connect();

                if(conn.getResponseCode()==HttpURLConnection.HTTP_OK){
                    InputStreamReader inputStreamReader = new InputStreamReader(conn.getInputStream());
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    StringBuilder stringBuilder = new StringBuilder();
                    String temp;
                    while((temp= bufferedReader.readLine())!=null){
                        stringBuilder.append(temp);
                    }
                    result=stringBuilder.toString();
                } else {
                    result="error";
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        public void onPostExecute(String s){
            super.equals(s);


            try {
                JSONObject object = new JSONObject(s);
                JSONArray array = object.getJSONArray("data");

                for(int i=0;i<array.length();i++){
                    JSONObject jsonObject = array.getJSONObject(i);
                    int numar= Integer.parseInt(jsonObject.getString("numar"));
                    String plecare=jsonObject.getString("plecare");
                    String destinatie=jsonObject.getString("destinatie");
                    String tarifRedus=jsonObject.getString("tarifRedus");
                    float pret=Float.parseFloat(jsonObject.getString("pret"));

                    Rezervare r = new Rezervare(numar,plecare,destinatie,tarifRedus,pret);

                    arrayList.add(r);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    }
}