package com.example.rezervari;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class ListaRezervari extends AppCompatActivity {

    ListView listView;
    List<Rezervare> arrayList= new ArrayList<>();
    ArrayAdapter<Rezervare> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_rezervari);
        listView = (ListView) findViewById(R.id.list_view);

        Bundle bundle = getIntent().getExtras();
        arrayList = (ArrayList<Rezervare>) bundle.getSerializable("Rezervari");
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(arrayAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Rezervare r = arrayList.get(position);

                Bundle bundle = new Bundle();
                bundle.putSerializable("Rezervare", r);

                Intent intent = new Intent(ListaRezervari.this, EliberareRezervare.class);
                intent.putExtras(bundle);
                startActivity(intent);

            }
        });
    }
}