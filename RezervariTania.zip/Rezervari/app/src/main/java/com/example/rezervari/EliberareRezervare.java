package com.example.rezervari;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.util.Date;

import static android.widget.ArrayAdapter.createFromResource;

public class EliberareRezervare extends AppCompatActivity {

    public static final String REZERVARE_KEY = "rezervare_key";
    EditText etNumar, etDestinatie, etPlecare, etPret;
    CheckBox cb;
    Button btn;
    private AppDatabase mDb;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliberare_rezervare);
        initComponents();
        btn.setOnClickListener(addSaveClickEvent());
        intent = getIntent();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        mDb = AppDatabase.getInstance(getApplicationContext());


        Bundle bundle = getIntent().getExtras();
    if(bundle!=null) {
        Rezervare r = (Rezervare) bundle.getSerializable("Rezervare");
        etNumar.setText(String.valueOf(r.getNumar()));
        etPlecare.setText(r.getPlecare());
        etDestinatie.setText(r.getDestinatie());
        etPret.setText(String.valueOf(r.getPret()));
        if (r.getTarifRedus() == "DA")
        {
            cb.setChecked(true);
        }
    }

    }

    private void initComponents() {

       etNumar = findViewById(R.id.editNumar);
       etPlecare = findViewById(R.id.editPlecare);
       etDestinatie = findViewById(R.id.editDestinatie);
       etPret = findViewById(R.id.editPret);
        cb= (CheckBox)findViewById(R.id.checkBox);
        btn = findViewById(R.id.button6);

    }



    private View.OnClickListener addSaveClickEvent() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //validarea campurilor de intrare
                if (validate()) {

                    Rezervare r = buildFromWidgets();

                    intent.putExtra(REZERVARE_KEY, r);
                    //trimiterea intent-ului catre MainActivity
                    setResult(RESULT_OK, intent);
                    AppExecutors.getInstance().diskIO().execute(new Runnable() {
                        @Override
                        public void run() {
                            mDb.rezervareDao().insertRezervare(r);
                            finish();
                        }
                    });
                    finish();

                }
            }
        };
    }

    private boolean validate() {
        //validare pentru campul name
        if (etNumar.getText() == null ) {

            Toast.makeText(getApplicationContext(),
                    R.string.add_numar_error,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }

        if (etPlecare.getText() == null ||etPlecare.getText().toString().trim().length() < 3) {
            Toast.makeText(getApplicationContext(),
                    R.string.add_plecare_error,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }

        if (etDestinatie.getText() == null
                ||etDestinatie.getText().toString().trim().length() < 3) {
            Toast.makeText(getApplicationContext(),
                    R.string.add_destinatie_error,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }

        if (etPret.getText() == null
                ||etPret.getText().toString().trim().length() < 3) {
            Toast.makeText(getApplicationContext(),
                    R.string.add_pret_error,
                    Toast.LENGTH_LONG)
                    .show();
            return false;
        }
        return true;
    }

    private Rezervare buildFromWidgets() {

        String plecare = etPlecare.getText().toString();
        int numar = Integer.parseInt(etNumar.getText().toString().trim());
        String destinatie =etDestinatie.getText().toString();
        float pret =Float.parseFloat(etPret.getText().toString().trim());
        String tarifRedus;
        if(cb.isChecked()){
            tarifRedus="DA";
        }
        else{
          tarifRedus="NU";
        }

        return new Rezervare(numar, plecare, destinatie,tarifRedus, pret);
    }
}