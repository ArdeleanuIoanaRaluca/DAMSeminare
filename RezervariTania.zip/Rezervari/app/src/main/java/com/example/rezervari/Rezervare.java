package com.example.rezervari;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "rezervare")
public class Rezervare implements Serializable {
    @PrimaryKey(autoGenerate = true)
    int id;
int numar;
String plecare;
String destinatie;
String tarifRedus;
float pret;

@Ignore
public Rezervare(int numar,String plecare,String destinatie,String tarifRedus,float pret)
{
    this.numar=numar;
    this.plecare=plecare;
    this.destinatie=destinatie;
    this.tarifRedus=tarifRedus;
    this.pret=pret;

}

    public Rezervare(int id,int numar,String plecare,String destinatie,String tarifRedus,float pret)
    {
        this.id=id;
        this.numar=numar;
        this.plecare=plecare;
        this.destinatie=destinatie;
        this.tarifRedus=tarifRedus;
        this.pret=pret;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumar() {
        return numar;
    }

    public void setNumar(int numar) {
        this.numar = numar;
    }

    public String getPlecare() {
        return plecare;
    }

    public void setPlecare(String plecare) {
        this.plecare = plecare;
    }

    public String getDestinatie() {
        return destinatie;
    }

    public void setDestinatie(String destinatie) {
        this.destinatie = destinatie;
    }

    public String getTarifRedus() {
        return tarifRedus;
    }

    public void setTarifRedus(String tarifRedus) {
        this.tarifRedus = tarifRedus;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    @Override
    public String toString() {
        return "Rezervare{" +
                "numar=" + numar +
                ", plecare='" + plecare + '\'' +
                ", destinatie='" + destinatie + '\'' +
                ", tarifRedus='" + tarifRedus + '\'' +
                ", pret=" + pret +
                '}';
    }
}
